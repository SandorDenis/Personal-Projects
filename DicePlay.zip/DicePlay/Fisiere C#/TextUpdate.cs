﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TextUpdate : MonoBehaviour
{
    public Text textBox;

    public void SetText(string txt)
    {
        textBox.text = txt;
    }
}
