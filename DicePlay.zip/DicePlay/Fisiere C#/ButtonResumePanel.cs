﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonResumePanel : MonoBehaviour
{

    public void ButtonResume()
    {
        PausePanel.panelPause.gameObject.SetActive(false);
        Dice.cartonas.gameObject.SetActive(true);
    }

    public void ButtonExit()
    {
        Application.Quit();
    }

}
