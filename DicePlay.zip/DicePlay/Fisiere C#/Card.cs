﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class Card : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    Vector3 cachedScale;
    TextUpdate script;
    public static string textCard = "";

    void Start()
    {
        cachedScale = transform.localScale;
        script = gameObject.GetComponent<TextUpdate>();
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        transform.localScale = new Vector3(3.7f, 4.5f, 0.0f);
        script.SetText(textCard);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        transform.localScale = cachedScale;
        script.SetText("");
    }
}
