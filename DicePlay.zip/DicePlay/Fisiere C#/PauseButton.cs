﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PauseButton : MonoBehaviour
{
    private void OnMouseDown()
    {
        PausePanel.panelPause.gameObject.SetActive(true);
        Dice.cartonas.gameObject.SetActive(false);
    }
}
