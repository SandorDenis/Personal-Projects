﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Control : MonoBehaviour
{
    public static GameObject player1MoveText, player2MoveText, player3MoveText, player4MoveText;
    public static GameObject player1, player2, player3, player4;

    public static List<int> order = new List<int>();

    public static int diceSideThrown = 0;
    public static int player1StartWaypoint = 0;
    public static int player2StartWaypoint = 0;
    public static int player3StartWaypoint = 0;
    public static int player4StartWaypoint = 0;
    public static bool gameOver = false;


    // Start is called before the first frame update
    void Start()
    {
        player1MoveText = GameObject.Find("Player1MoveText");
        player2MoveText = GameObject.Find("Player2MoveText");
        player3MoveText = GameObject.Find("Player3MoveText");
        player4MoveText = GameObject.Find("Player4MoveText");

        player1 = GameObject.Find("Player1");
        player2 = GameObject.Find("Player2");
        player3 = GameObject.Find("Player3");
        player4 = GameObject.Find("Player4");

        player1.GetComponent<Path>().movement = false;
        player2.GetComponent<Path>().movement = false;
        player3.GetComponent<Path>().movement = false;
        player4.GetComponent<Path>().movement = false;

        player1MoveText.gameObject.SetActive(true);
        player2MoveText.gameObject.SetActive(false);
        player3MoveText.gameObject.SetActive(false);
        player4MoveText.gameObject.SetActive(false);


    }

    // Update is called once per frame
    void Update()
    {
        if (player1.GetComponent<Path>().waypointIndex == 11 && player1StartWaypoint + diceSideThrown == 10)
        {
            player1StartWaypoint = 15 - diceSideThrown;
            player1.GetComponent<Path>().waypointIndex = player1StartWaypoint;
        }
        if (player2.GetComponent<Path>().waypointIndex == 11 && player2StartWaypoint + diceSideThrown == 10)
        {
            player2StartWaypoint = 15 - diceSideThrown;
            player2.GetComponent<Path>().waypointIndex = player2StartWaypoint;
        }
        if (player3.GetComponent<Path>().waypointIndex == 11 && player3StartWaypoint + diceSideThrown == 10)
        {
            player3StartWaypoint = 15 - diceSideThrown;
            player3.GetComponent<Path>().waypointIndex = player3StartWaypoint;
        }
        if (player4.GetComponent<Path>().waypointIndex == 11 && player4StartWaypoint + diceSideThrown == 10)
        {
            player4StartWaypoint = 15 - diceSideThrown;
            player4.GetComponent<Path>().waypointIndex = player4StartWaypoint;
        }

        if (player1.GetComponent<Path>().waypointIndex == 21 && player1StartWaypoint + diceSideThrown == 20)
        {
            if (diceSideThrown == 6)
            {
                diceSideThrown--;
            }
            if (diceSideThrown == 5)
            {
                player1StartWaypoint = 0;
                player1.GetComponent<Path>().waypointIndex = player1StartWaypoint;
            }
            if (diceSideThrown == 4)
            {
                player1StartWaypoint = 1;
                player1.GetComponent<Path>().waypointIndex = player1StartWaypoint;
            }
            if (diceSideThrown == 3)
            {
                player1StartWaypoint = 2;
                player1.GetComponent<Path>().waypointIndex = player1StartWaypoint;
            }
            if (diceSideThrown == 2)
            {
                player1StartWaypoint = 3;
                player1.GetComponent<Path>().waypointIndex = player1StartWaypoint;
            }
            if (diceSideThrown == 1)
            {
                player1StartWaypoint = 4;
                player1.GetComponent<Path>().waypointIndex = player1StartWaypoint;
            }

        }
        if (player2.GetComponent<Path>().waypointIndex == 21 && player2StartWaypoint + diceSideThrown == 20)
        {
                if (diceSideThrown == 6)
                {
                    diceSideThrown--;
                }
                if (diceSideThrown == 5)
                {
                    player2StartWaypoint = 0;
                    player2.GetComponent<Path>().waypointIndex = player2StartWaypoint;
                }
                if (diceSideThrown == 4)
                {
                    player2StartWaypoint = 1;
                    player2.GetComponent<Path>().waypointIndex = player2StartWaypoint;
                }
                if (diceSideThrown == 3)
                {
                    player2StartWaypoint = 2;
                    player2.GetComponent<Path>().waypointIndex = player2StartWaypoint;
                }
                if (diceSideThrown == 2)
                {
                    player2StartWaypoint = 3;
                    player2.GetComponent<Path>().waypointIndex = player2StartWaypoint;
                }
                if (diceSideThrown == 1)
                {
                    player2StartWaypoint = 4;
                    player2.GetComponent<Path>().waypointIndex = player2StartWaypoint;
                }
        }
        if (player3.GetComponent<Path>().waypointIndex == 21 && player3StartWaypoint + diceSideThrown == 20)
        {
            if (diceSideThrown == 6)
            {
                diceSideThrown--;
            }
            if (diceSideThrown == 5)
            {
                player3StartWaypoint = 0;
                player3.GetComponent<Path>().waypointIndex = player3StartWaypoint;
            }
            if (diceSideThrown == 4)
            {
                player3StartWaypoint = 1;
                player3.GetComponent<Path>().waypointIndex = player3StartWaypoint;
            }
            if (diceSideThrown == 3)
            {
                player3StartWaypoint = 2;
                player3.GetComponent<Path>().waypointIndex = player3StartWaypoint;
            }
            if (diceSideThrown == 2)
            {
                player3StartWaypoint = 3;
                player3.GetComponent<Path>().waypointIndex = player3StartWaypoint;
            }
            if (diceSideThrown == 1)
            {
                player3StartWaypoint = 4;
                player3.GetComponent<Path>().waypointIndex = player3StartWaypoint;
            }
        }
        if (player4.GetComponent<Path>().waypointIndex == 21 && player4StartWaypoint + diceSideThrown == 20)
        {
            if (diceSideThrown == 6)
            {
                diceSideThrown--;
            }
            if (diceSideThrown == 5)
            {
                player4StartWaypoint = 0;
                player4.GetComponent<Path>().waypointIndex = player4StartWaypoint;
            }
            if (diceSideThrown == 4)
            {
                player4StartWaypoint = 1;
                player4.GetComponent<Path>().waypointIndex = player4StartWaypoint;
            }
            if (diceSideThrown == 3)
            {
                player4StartWaypoint = 2;
                player4.GetComponent<Path>().waypointIndex = player4StartWaypoint;
            }
            if (diceSideThrown == 2)
            {
                player4StartWaypoint = 3;
                player4.GetComponent<Path>().waypointIndex = player4StartWaypoint;
            }
            if (diceSideThrown == 1)
            {
                player4StartWaypoint = 4;
                player4.GetComponent<Path>().waypointIndex = player4StartWaypoint;
            }
        }
        if (player1.GetComponent<Path>().waypointIndex == 26 && player1StartWaypoint + diceSideThrown == 25)
        {
            player1StartWaypoint = 34 - diceSideThrown;
        }
        if (player2.GetComponent<Path>().waypointIndex == 26 && player2StartWaypoint + diceSideThrown == 25)
        {
            player2StartWaypoint = 34 - diceSideThrown;
        }
        if (player3.GetComponent<Path>().waypointIndex == 26 && player3StartWaypoint + diceSideThrown == 25)
        {
            player3StartWaypoint = 34 - diceSideThrown;
        }
        if (player4.GetComponent<Path>().waypointIndex == 26 && player4StartWaypoint + diceSideThrown == 25)
        {
            player4StartWaypoint = 34 - diceSideThrown;
        }
        if (player1.GetComponent<Path>().waypointIndex == 41 && player1StartWaypoint + diceSideThrown == 40)
        {
            player1StartWaypoint = 30 - diceSideThrown;
            player1.GetComponent<Path>().waypointIndex = player1StartWaypoint - diceSideThrown;
        }
        if (player2.GetComponent<Path>().waypointIndex == 41 && player2StartWaypoint + diceSideThrown == 40)
        {
            player2StartWaypoint = 30 - diceSideThrown;
            player2.GetComponent<Path>().waypointIndex = player2StartWaypoint - diceSideThrown;
        }
        if (player3.GetComponent<Path>().waypointIndex == 41 && player3StartWaypoint + diceSideThrown == 40)
        {
            player3StartWaypoint = 30 - diceSideThrown;
            player3.GetComponent<Path>().waypointIndex = player3StartWaypoint - diceSideThrown;
        }
        if (player4.GetComponent<Path>().waypointIndex == 41 && player4StartWaypoint + diceSideThrown == 40)
        {
            player4StartWaypoint = 30 - diceSideThrown;
            player4.GetComponent<Path>().waypointIndex = player4StartWaypoint - diceSideThrown;
        }

        if (ColorChange.enabledPlayers == 2)
        {
            if (player1.GetComponent<Path>().waypointIndex > player1StartWaypoint + diceSideThrown)
            {
                player1.GetComponent<Path>().movement = false;
                player1MoveText.gameObject.SetActive(false);
                player2MoveText.gameObject.SetActive(true);
                player3MoveText.gameObject.SetActive(false);
                player4MoveText.gameObject.SetActive(false);
                player1StartWaypoint = player1.GetComponent<Path>().waypointIndex - 1;
            }

            if (player2.GetComponent<Path>().waypointIndex > player2StartWaypoint + diceSideThrown)
            {
                player2.GetComponent<Path>().movement = false;
                player2MoveText.gameObject.SetActive(false);
                player1MoveText.gameObject.SetActive(true);
                player3MoveText.gameObject.SetActive(false);
                player4MoveText.gameObject.SetActive(false);
                player2StartWaypoint = player2.GetComponent<Path>().waypointIndex - 1;
            }
        }

        if (ColorChange.enabledPlayers == 3)
        {
            if (player1.GetComponent<Path>().waypointIndex > player1StartWaypoint + diceSideThrown)
            {
                player1.GetComponent<Path>().movement = false;
                player1MoveText.gameObject.SetActive(false);
                player2MoveText.gameObject.SetActive(true);
                player3MoveText.gameObject.SetActive(false);
                player4MoveText.gameObject.SetActive(false);
                player1StartWaypoint = player1.GetComponent<Path>().waypointIndex - 1;
            }

            if (player2.GetComponent<Path>().waypointIndex > player2StartWaypoint + diceSideThrown)
            {
                player2.GetComponent<Path>().movement = false;
                player2MoveText.gameObject.SetActive(false);
                player1MoveText.gameObject.SetActive(false);
                player3MoveText.gameObject.SetActive(true);
                player4MoveText.gameObject.SetActive(false);
                player2StartWaypoint = player2.GetComponent<Path>().waypointIndex - 1;
            }

            if (player3.GetComponent<Path>().waypointIndex > player3StartWaypoint + diceSideThrown)
            {
                player3.GetComponent<Path>().movement = false;
                player2MoveText.gameObject.SetActive(false);
                player1MoveText.gameObject.SetActive(true);
                player3MoveText.gameObject.SetActive(false);
                player4MoveText.gameObject.SetActive(false);
                player3StartWaypoint = player3.GetComponent<Path>().waypointIndex - 1;
            }
        }

        if (ColorChange.enabledPlayers == 4)
        {
            if (player1.GetComponent<Path>().waypointIndex > player1StartWaypoint + diceSideThrown)
            {
                player1.GetComponent<Path>().movement = false;
                player1MoveText.gameObject.SetActive(false);
                player2MoveText.gameObject.SetActive(true);
                player3MoveText.gameObject.SetActive(false);
                player4MoveText.gameObject.SetActive(false);
                player1StartWaypoint = player1.GetComponent<Path>().waypointIndex - 1;
            }

            if (player2.GetComponent<Path>().waypointIndex > player2StartWaypoint + diceSideThrown)
            {
                player2.GetComponent<Path>().movement = false;
                player2MoveText.gameObject.SetActive(false);
                player1MoveText.gameObject.SetActive(false);
                player3MoveText.gameObject.SetActive(true);
                player4MoveText.gameObject.SetActive(false);
                player2StartWaypoint = player2.GetComponent<Path>().waypointIndex - 1;
            }

            if (player3.GetComponent<Path>().waypointIndex > player3StartWaypoint + diceSideThrown)
            {
                player3.GetComponent<Path>().movement = false;
                player2MoveText.gameObject.SetActive(false);
                player1MoveText.gameObject.SetActive(false);
                player3MoveText.gameObject.SetActive(false);
                player4MoveText.gameObject.SetActive(true);
                player3StartWaypoint = player3.GetComponent<Path>().waypointIndex - 1;
            }

            if (player4.GetComponent<Path>().waypointIndex > player4StartWaypoint + diceSideThrown)
            {
                player4.GetComponent<Path>().movement = false;
                player2MoveText.gameObject.SetActive(false);
                player1MoveText.gameObject.SetActive(true);
                player3MoveText.gameObject.SetActive(false);
                player4MoveText.gameObject.SetActive(false);
                player4StartWaypoint = player4.GetComponent<Path>().waypointIndex - 1;
            }
        }

        if (player1.GetComponent<Path>().waypointIndex == player1.GetComponent<Path>().waypoints.Length)
        {
            player1MoveText.gameObject.SetActive(false);
            player2MoveText.gameObject.SetActive(false);
            player3MoveText.gameObject.SetActive(false);
            player4MoveText.gameObject.SetActive(false);
            Dice.cartonas.gameObject.SetActive(false);
            Score.scoreP1.gameObject.SetActive(false);
            Score.scoreP2.gameObject.SetActive(false);
            Score.scoreP3.gameObject.SetActive(false);
            Score.scoreP4.gameObject.SetActive(false);
            player1MoveText.gameObject.SetActive(false);
            player2MoveText.gameObject.SetActive(false);
            player3MoveText.gameObject.SetActive(false);
            player4MoveText.gameObject.SetActive(false);
            ColorChange.imgP1.enabled = false;
            ColorChange.imgP2.enabled = false;
            ColorChange.imgP3.enabled = false;
            ColorChange.imgP4.enabled = false;
            PlayerName.numeP1.gameObject.SetActive(false);
            PlayerName.numeP2.gameObject.SetActive(false);
            PlayerName.numeP3.gameObject.SetActive(false);
            PlayerName.numeP4.gameObject.SetActive(false);
            Ranking.panelWinners.gameObject.SetActive(true);
            Ranking.winP1.text = "Locul 1: " + PlayerName.numeJucator1 + " Scor: " + Score.puncteP1.ToString();
            order.Add(player2.GetComponent<Path>().waypointIndex);
            order.Add(player3.GetComponent<Path>().waypointIndex);
            order.Add(player4.GetComponent<Path>().waypointIndex);
            order.Sort();
            order.Reverse();
            if (player2.GetComponent<Path>().waypointIndex == order[0] && order[0] != 0)
                Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString(); 
            if (player3.GetComponent<Path>().waypointIndex == order[0] && order[0] != 0)
                Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString(); 
            if (player4.GetComponent<Path>().waypointIndex == order[0] && order[0] != 0)
                Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString(); 

            if (player2.GetComponent<Path>().waypointIndex == order[1] && order[1] != 0)
                Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString(); 
            if (player3.GetComponent<Path>().waypointIndex == order[1] && order[1] != 0)
                Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString(); 
            if (player4.GetComponent<Path>().waypointIndex == order[1] && order[1] != 0)
                Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString(); 

            if (player2.GetComponent<Path>().waypointIndex == order[2] && order[2] != 0)
                Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator2 + "Scor: " + Score.puncteP2.ToString(); 
            if (player3.GetComponent<Path>().waypointIndex == order[2] && order[2] != 0)
                Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator3 + "Scor: " + Score.puncteP3.ToString(); 
            if (player4.GetComponent<Path>().waypointIndex == order[2] && order[2] != 0)
                Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator4 + "Scor: " + Score.puncteP4.ToString();

            if ((player2.GetComponent<Path>().waypointIndex == player3.GetComponent<Path>().waypointIndex &&
                (player2.GetComponent<Path>().waypointIndex == order[0] || player2.GetComponent<Path>().waypointIndex == order[1]) &&
                (player3.GetComponent<Path>().waypointIndex == order[0] || player3.GetComponent<Path>().waypointIndex == order[1])) && order[0] != 0 && order[1] != 0)
            {
                if (Score.puncteP2 > Score.puncteP3)
                {
                    Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString(); 
                    Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString(); 
                    Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString(); 
                }
                else
                {
                    Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString(); 
                    Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString(); 
                    Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();
                }
            }

            if ((player2.GetComponent<Path>().waypointIndex == player4.GetComponent<Path>().waypointIndex &&
                (player2.GetComponent<Path>().waypointIndex == order[0] || player2.GetComponent<Path>().waypointIndex == order[1]) &&
                (player4.GetComponent<Path>().waypointIndex == order[0] || player4.GetComponent<Path>().waypointIndex == order[1])) && order[0] != 0 && order[1] != 0)
            {
                if (Score.puncteP2 > Score.puncteP4)
                {
                    Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
                    Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();
                    Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString();
                }
                else
                {
                    Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();
                    Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
                    Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString();
                }
            }

            if ((player3.GetComponent<Path>().waypointIndex == player4.GetComponent<Path>().waypointIndex &&
                (player3.GetComponent<Path>().waypointIndex == order[0] || player3.GetComponent<Path>().waypointIndex == order[1]) &&
                (player4.GetComponent<Path>().waypointIndex == order[0] || player4.GetComponent<Path>().waypointIndex == order[1])) && order[0] != 0 && order[1] != 0)
            {
                if (Score.puncteP3 > Score.puncteP4)
                {
                    Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString();
                    Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();
                    Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
                }
                else
                {
                    Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();
                    Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString();
                    Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
                }
            }
            order.Clear();
            gameOver = true;
        }

        if (player2.GetComponent<Path>().waypointIndex == player2.GetComponent<Path>().waypoints.Length)
        {
            player1MoveText.gameObject.SetActive(false);
            player2MoveText.gameObject.SetActive(false);
            player3MoveText.gameObject.SetActive(false);
            player4MoveText.gameObject.SetActive(false);
            Dice.cartonas.gameObject.SetActive(false);
            Score.scoreP1.gameObject.SetActive(false);
            Score.scoreP2.gameObject.SetActive(false);
            Score.scoreP3.gameObject.SetActive(false);
            Score.scoreP4.gameObject.SetActive(false);
            player1MoveText.gameObject.SetActive(false);
            player2MoveText.gameObject.SetActive(false);
            player3MoveText.gameObject.SetActive(false);
            player4MoveText.gameObject.SetActive(false);
            ColorChange.imgP1.enabled = false;
            ColorChange.imgP2.enabled = false;
            ColorChange.imgP3.enabled = false;
            ColorChange.imgP4.enabled = false;
            PlayerName.numeP1.gameObject.SetActive(false);
            PlayerName.numeP2.gameObject.SetActive(false);
            PlayerName.numeP3.gameObject.SetActive(false);
            PlayerName.numeP4.gameObject.SetActive(false);
            Ranking.panelWinners.gameObject.SetActive(true);
            Ranking.winP1.text = "Locul 1: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
            order.Add(player1.GetComponent<Path>().waypointIndex);
            order.Add(player3.GetComponent<Path>().waypointIndex);
            order.Add(player4.GetComponent<Path>().waypointIndex);
            order.Sort();
            order.Reverse();
            if (player1.GetComponent<Path>().waypointIndex == order[0] && order[0] != 0)
                Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator1 + " Scor: " + Score.puncteP1.ToString();
            if (player3.GetComponent<Path>().waypointIndex == order[0] && order[0] != 0)
                Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString();
            if (player4.GetComponent<Path>().waypointIndex == order[0] && order[0] != 0)
                Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();

            if (player1.GetComponent<Path>().waypointIndex == order[1] && order[1] != 0)
                Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator1 + " Scor: " + Score.puncteP1.ToString();
            if (player3.GetComponent<Path>().waypointIndex == order[1] && order[1] != 0)
                Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString();
            if (player4.GetComponent<Path>().waypointIndex == order[1] && order[1] != 0)
                Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();

            if (player1.GetComponent<Path>().waypointIndex == order[2] && order[2] != 0)
                Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator1 + " Scor: " + Score.puncteP1.ToString();
            if (player3.GetComponent<Path>().waypointIndex == order[2] && order[2] != 0)
                Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP2.ToString();
            if (player4.GetComponent<Path>().waypointIndex == order[2] && order[2] != 0)
                Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();

            if ((player1.GetComponent<Path>().waypointIndex == player3.GetComponent<Path>().waypointIndex &&
                (player1.GetComponent<Path>().waypointIndex == order[0] || player1.GetComponent<Path>().waypointIndex == order[1]) &&
                (player3.GetComponent<Path>().waypointIndex == order[0] || player3.GetComponent<Path>().waypointIndex == order[1])) && order[0] != 0 && order[1] != 0)
            {
                if (Score.puncteP1 > Score.puncteP3)
                {
                    Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator1 + " Scor: " + Score.puncteP1.ToString();
                    Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString();
                    Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();
                }
                else
                {
                    Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString();
                    Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator1 + " Scor: " + Score.puncteP1.ToString();
                    Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();
                }
            }

            if ((player1.GetComponent<Path>().waypointIndex == player4.GetComponent<Path>().waypointIndex &&
                (player1.GetComponent<Path>().waypointIndex == order[0] || player1.GetComponent<Path>().waypointIndex == order[1]) &&
                (player4.GetComponent<Path>().waypointIndex == order[0] || player4.GetComponent<Path>().waypointIndex == order[1])) && order[0] != 0 && order[1] != 0)
            {
                if (Score.puncteP1 > Score.puncteP4)
                {
                    Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator1 + " Scor: " + Score.puncteP1.ToString();
                    Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();
                    Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString();
                }
                else
                {
                    Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();
                    Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator1 + " Scor: " + Score.puncteP1.ToString();
                    Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString();
                }
            }

            if ((player3.GetComponent<Path>().waypointIndex == player4.GetComponent<Path>().waypointIndex &&
                (player3.GetComponent<Path>().waypointIndex == order[0] || player3.GetComponent<Path>().waypointIndex == order[1]) &&
                (player4.GetComponent<Path>().waypointIndex == order[0] || player4.GetComponent<Path>().waypointIndex == order[1])) && order[0] != 0 && order[1] != 0)
            {
                if (Score.puncteP3 > Score.puncteP4)
                {
                    Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString();
                    Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();
                    Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
                }
                else
                {
                    Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();
                    Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString();
                    Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
                }
            }
            order.Clear();
            gameOver = true;
        }

        if (player3.GetComponent<Path>().waypointIndex == player3.GetComponent<Path>().waypoints.Length)
        {
            player1MoveText.gameObject.SetActive(false);
            player2MoveText.gameObject.SetActive(false);
            player3MoveText.gameObject.SetActive(false);
            player4MoveText.gameObject.SetActive(false);
            Dice.cartonas.gameObject.SetActive(false);
            Score.scoreP1.gameObject.SetActive(false);
            Score.scoreP2.gameObject.SetActive(false);
            Score.scoreP3.gameObject.SetActive(false);
            Score.scoreP4.gameObject.SetActive(false);
            player1MoveText.gameObject.SetActive(false);
            player2MoveText.gameObject.SetActive(false);
            player3MoveText.gameObject.SetActive(false);
            player4MoveText.gameObject.SetActive(false);
            ColorChange.imgP1.enabled = false;
            ColorChange.imgP2.enabled = false;
            ColorChange.imgP3.enabled = false;
            ColorChange.imgP4.enabled = false;
            PlayerName.numeP1.gameObject.SetActive(false);
            PlayerName.numeP2.gameObject.SetActive(false);
            PlayerName.numeP3.gameObject.SetActive(false);
            PlayerName.numeP4.gameObject.SetActive(false);
            Ranking.panelWinners.gameObject.SetActive(true);
            Ranking.winP1.text = "Locul 1: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString();
            order.Add(player1.GetComponent<Path>().waypointIndex);
            order.Add(player2.GetComponent<Path>().waypointIndex);
            order.Add(player4.GetComponent<Path>().waypointIndex);
            order.Sort();
            order.Reverse();
            if (player2.GetComponent<Path>().waypointIndex == order[0] && order[0] != 0)
                Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
            if (player1.GetComponent<Path>().waypointIndex == order[0] && order[0] != 0)
                Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator1 + " Scor: " + Score.puncteP1.ToString();
            if (player4.GetComponent<Path>().waypointIndex == order[0] && order[0] != 0)
                Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();

            if (player2.GetComponent<Path>().waypointIndex == order[1] && order[1] != 0)
                Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
            if (player1.GetComponent<Path>().waypointIndex == order[1] && order[1] != 0)
                Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator1 + " Scor: " + Score.puncteP1.ToString();
            if (player4.GetComponent<Path>().waypointIndex == order[1] && order[1] != 0)
                Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();

            if (player2.GetComponent<Path>().waypointIndex == order[2] && order[2] != 0)
                Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
            if (player1.GetComponent<Path>().waypointIndex == order[2] && order[2] != 0)
                Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator1 + " Scor: " + Score.puncteP1.ToString();
            if (player4.GetComponent<Path>().waypointIndex == order[2] && order[2] != 0)
                Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();

            if ((player2.GetComponent<Path>().waypointIndex == player1.GetComponent<Path>().waypointIndex &&
                (player2.GetComponent<Path>().waypointIndex == order[0] || player2.GetComponent<Path>().waypointIndex == order[1]) &&
                (player1.GetComponent<Path>().waypointIndex == order[0] || player1.GetComponent<Path>().waypointIndex == order[1])) && order[0] != 0 && order[1] != 0)
            {
                if (Score.puncteP2 > Score.puncteP1)
                {
                    Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
                    Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator1 + " Scor: " + Score.puncteP1.ToString();
                    Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();
                }
                else
                {
                    Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator1 + " Scor: " + Score.puncteP1.ToString();
                    Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
                    Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();
                }
            }

            if ((player2.GetComponent<Path>().waypointIndex == player4.GetComponent<Path>().waypointIndex &&
                (player2.GetComponent<Path>().waypointIndex == order[0] || player2.GetComponent<Path>().waypointIndex == order[1]) &&
                (player4.GetComponent<Path>().waypointIndex == order[0] || player4.GetComponent<Path>().waypointIndex == order[1])) && order[0] != 0 && order[1] != 0)
            {
                if (Score.puncteP2 > Score.puncteP4)
                {
                    Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
                    Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();
                    Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString();
                }
                else
                {
                    Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();
                    Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
                    Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString();
                }
            }

            if ((player1.GetComponent<Path>().waypointIndex == player4.GetComponent<Path>().waypointIndex &&
                (player1.GetComponent<Path>().waypointIndex == order[0] || player1.GetComponent<Path>().waypointIndex == order[1]) &&
                (player4.GetComponent<Path>().waypointIndex == order[0] || player4.GetComponent<Path>().waypointIndex == order[1])) && order[0] != 0 && order[1] != 0)
            {
                if (Score.puncteP1 > Score.puncteP4)
                {
                    Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator1 + " Scor: " + Score.puncteP1.ToString();
                    Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();
                    Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
                }
                else
                {
                    Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();
                    Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator1 + " Scor: " + Score.puncteP1.ToString();
                    Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
                }
            }
            order.Clear();
            gameOver = true;
        }

        if (player4.GetComponent<Path>().waypointIndex == player4.GetComponent<Path>().waypoints.Length)
        {
            player1MoveText.gameObject.SetActive(false);
            player2MoveText.gameObject.SetActive(false);
            player3MoveText.gameObject.SetActive(false);
            player4MoveText.gameObject.SetActive(false);
            Dice.cartonas.gameObject.SetActive(false);
            Score.scoreP1.gameObject.SetActive(false);
            Score.scoreP2.gameObject.SetActive(false);
            Score.scoreP3.gameObject.SetActive(false);
            Score.scoreP4.gameObject.SetActive(false);
            player1MoveText.gameObject.SetActive(false);
            player2MoveText.gameObject.SetActive(false);
            player3MoveText.gameObject.SetActive(false);
            player4MoveText.gameObject.SetActive(false);
            ColorChange.imgP1.enabled = false;
            ColorChange.imgP2.enabled = false;
            ColorChange.imgP3.enabled = false;
            ColorChange.imgP4.enabled = false;
            PlayerName.numeP1.gameObject.SetActive(false);
            PlayerName.numeP2.gameObject.SetActive(false);
            PlayerName.numeP3.gameObject.SetActive(false);
            PlayerName.numeP4.gameObject.SetActive(false);
            Ranking.panelWinners.gameObject.SetActive(true);
            Ranking.winP1.text = "Locul 1: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();
            order.Add(player2.GetComponent<Path>().waypointIndex);
            order.Add(player3.GetComponent<Path>().waypointIndex);
            order.Add(player1.GetComponent<Path>().waypointIndex);
            order.Sort();
            order.Reverse();
            if (player2.GetComponent<Path>().waypointIndex == order[0] && order[0] != 0)
                Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
            if (player3.GetComponent<Path>().waypointIndex == order[0] && order[0] != 0)
                Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString();
            if (player1.GetComponent<Path>().waypointIndex == order[0] && order[0] != 0)
                Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator1 + " Scor: " + Score.puncteP1.ToString();

            if (player2.GetComponent<Path>().waypointIndex == order[1] && order[1] != 0)
                Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
            if (player3.GetComponent<Path>().waypointIndex == order[1] && order[1] != 0)
                Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString();
            if (player1.GetComponent<Path>().waypointIndex == order[1] && order[1] != 0)
                Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator1 + " Scor: " + Score.puncteP1.ToString();

            if (player2.GetComponent<Path>().waypointIndex == order[2] && order[2] != 0)
                Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
            if (player3.GetComponent<Path>().waypointIndex == order[2] && order[2] != 0)
                Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString();
            if (player1.GetComponent<Path>().waypointIndex == order[2] && order[2] != 0)
                Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator1 + " Scor: " + Score.puncteP1.ToString();

            if ((player2.GetComponent<Path>().waypointIndex == player3.GetComponent<Path>().waypointIndex &&
                (player2.GetComponent<Path>().waypointIndex == order[0] || player2.GetComponent<Path>().waypointIndex == order[1]) &&
                (player3.GetComponent<Path>().waypointIndex == order[0] || player3.GetComponent<Path>().waypointIndex == order[1])) && order[0] != 0 && order[1] != 0)
            {
                if (Score.puncteP2 > Score.puncteP3)
                {
                    Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
                    Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString();
                    Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();
                }
                else
                {
                    Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString();
                    Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
                    Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator4 + " Scor: " + Score.puncteP4.ToString();
                }
            }

            if ((player2.GetComponent<Path>().waypointIndex == player1.GetComponent<Path>().waypointIndex &&
                (player2.GetComponent<Path>().waypointIndex == order[0] || player2.GetComponent<Path>().waypointIndex == order[1]) &&
                (player1.GetComponent<Path>().waypointIndex == order[0] || player1.GetComponent<Path>().waypointIndex == order[1])) && order[0] != 0 && order[1] != 0)
            {
                if (Score.puncteP2 > Score.puncteP1)
                {
                    Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
                    Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator1 + " Scor: " + Score.puncteP1.ToString();
                    Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString();
                }
                else
                {
                    Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator1 + " Scor: " + Score.puncteP1.ToString();
                    Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
                    Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString();
                }
            }

            if ((player3.GetComponent<Path>().waypointIndex == player1.GetComponent<Path>().waypointIndex &&
                (player3.GetComponent<Path>().waypointIndex == order[0] || player3.GetComponent<Path>().waypointIndex == order[1]) &&
                (player1.GetComponent<Path>().waypointIndex == order[0] || player1.GetComponent<Path>().waypointIndex == order[1])) && order[0] != 0 && order[1] != 0)
            {
                if (Score.puncteP3 > Score.puncteP1)
                {
                    Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString();
                    Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator1 + " Scor: " + Score.puncteP1.ToString();
                    Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
                }
                else
                {
                    Ranking.winP2.text = "Locul 2: " + PlayerName.numeJucator1 + " Scor: " + Score.puncteP1.ToString();
                    Ranking.winP3.text = "Locul 3: " + PlayerName.numeJucator3 + " Scor: " + Score.puncteP3.ToString();
                    Ranking.winP4.text = "Locul 4: " + PlayerName.numeJucator2 + " Scor: " + Score.puncteP2.ToString();
                }
            }
            order.Clear();
            gameOver = true;
        }

    }

    public static void MovePlayer(int playerToMove)
    {
        switch (playerToMove)
        {
            case 1:
                player1.GetComponent<Path>().movement = true;
                break;

            case 2:
                player2.GetComponent<Path>().movement = true;
                break;

            case 3:
                player3.GetComponent<Path>().movement = true;
                break;

            case 4:
                player4.GetComponent<Path>().movement = true;
                break;
        }
    }
}
