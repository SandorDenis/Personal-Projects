﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Ranking : MonoBehaviour
{
    public static Text winP1, winP2, winP3, winP4;

    public static GameObject panelWinners;

    // Start is called before the first frame update
    void Start()
    {
        winP1 = transform.Find("P1WinText").GetComponent<Text>();
        winP2 = transform.Find("P2WinText").GetComponent<Text>();
        winP3 = transform.Find("P3WinText").GetComponent<Text>();
        winP4 = transform.Find("P4WinText").GetComponent<Text>();

        panelWinners = GameObject.Find("WinnerScreen");
        panelWinners.gameObject.SetActive(false);
    }

    // Update is called once per frame
}
