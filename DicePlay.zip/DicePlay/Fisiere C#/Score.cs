﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour
{
    public static int puncteP1 = 0, puncteP2 = 0, puncteP3 = 0, puncteP4 = 0;
    public static Text scoreP1, scoreP2, scoreP3, scoreP4;

    // Start is called before the first frame update
    void Start()
    {
        scoreP1 = transform.Find("Text1").GetComponent<Text>();
        scoreP2 = transform.Find("Text2").GetComponent<Text>();
        scoreP3 = transform.Find("Text3").GetComponent<Text>();
        scoreP4 = transform.Find("Text4").GetComponent<Text>();

        scoreP1.text = "Scor: " + puncteP1.ToString();
        scoreP2.text = "Scor: " + puncteP2.ToString();
        scoreP3.text = "Scor: " + puncteP3.ToString();
        scoreP4.text = "Scor: " + puncteP4.ToString();
    }

    // Update is called once per frame
    void Update()
    {
        scoreP1.text = "Scor: " + puncteP1.ToString();
        scoreP2.text = "Scor: " + puncteP2.ToString();
        scoreP3.text = "Scor: " + puncteP3.ToString();
        scoreP4.text = "Scor: " + puncteP4.ToString();
    }
}
