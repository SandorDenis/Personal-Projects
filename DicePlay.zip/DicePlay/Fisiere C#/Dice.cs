﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Dice : MonoBehaviour
{
    private Sprite[] diceSides, cartonase;
    private SpriteRenderer rend, rendCartonas;
    public static Image cartonas;
    public static int turn = 1;
    public static bool ok = true;

    GameObject P1;


    // Start is called before the first frame update
    void Start()
    {
        rend = GetComponent<SpriteRenderer>();
        cartonas = GameObject.Find("Cartonas").GetComponent<Image>();
        diceSides = Resources.LoadAll<Sprite>("Dice/");
        cartonase = Resources.LoadAll<Sprite>("Cartonase/");
        rend.sprite = diceSides[5];
        rendCartonas = GetComponent<SpriteRenderer>();

    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnMouseDown()
    {
        if (!Control.gameOver && ok)
            StartCoroutine("Roll");
    }


        private IEnumerator Roll()
    {
        ok = false;
        int r = 0;
        int rCard = 0;
        for (int i = 0; i<= 20; i++)
        {
            r = Random.Range(0, 5);
            rCard = Random.Range(0, 6);
            rend.sprite = diceSides[r];
            yield return new WaitForSeconds(0.05f);
        }
        cartonas.overrideSprite = cartonase[rCard];


        Control.diceSideThrown = r + 1;
        if (ColorChange.enabledPlayers == 2)
        {
            if (turn == 1)
            {
                if (rCard == 0)
                {
                    Card.textCard = "5 puncte bonus";
                    Score.puncteP1 += 5;
                }
                if (rCard == 1)
                {
                    Card.textCard = "1 punct bonus";
                    Score.puncteP1 += 1;
                }
                if (rCard == 2)
                {
                    Card.textCard = "-1 punct";
                    Score.puncteP1 -= 1;
                }
                if (rCard == 3)
                {
                    Card.textCard = "-3 puncte";
                    Score.puncteP1 -= 3;
                }
                if (rCard == 4)
                {
                    Card.textCard = "7 puncte bonus";
                    Score.puncteP1 += 7;
                }
                if (rCard == 5)
                {
                    Card.textCard = "2 puncte bonus";
                    Score.puncteP1 += 2;
                }
                Control.MovePlayer(1);
                turn++;
            }
            else if (turn == 2)
            {
                if (rCard == 0)
                {
                    Card.textCard = "5 puncte bonus";
                    Score.puncteP2 += 5;
                }
                if (rCard == 1)
                {
                    Card.textCard = "1 punct bonus";
                    Score.puncteP2 += 1;
                }
                if (rCard == 2)
                {
                    Card.textCard = "-1 punct";
                    Score.puncteP2 -= 1;
                }
                if (rCard == 3)
                {
                    Card.textCard = "-3 puncte";
                    Score.puncteP2 -= 3;
                }
                if (rCard == 4)
                {
                    Card.textCard = "7 puncte bonus";
                    Score.puncteP2 += 7;
                }
                if (rCard == 5)
                {
                    Card.textCard = "2 puncte bonus";
                    Score.puncteP2 += 2;
                }
                Control.MovePlayer(2);
                turn = 1;
            }
        }
        if (ColorChange.enabledPlayers == 3)
        {
            if (turn == 1)
            {
                if (rCard == 0)
                {
                    Card.textCard = "5 puncte bonus";
                    Score.puncteP1 += 5;
                }
                if (rCard == 1)
                {
                    Card.textCard = "1 punct bonus";
                    Score.puncteP1 += 1;
                }
                if (rCard == 2)
                {
                    Card.textCard = "-1 punct";
                    Score.puncteP1 -= 1;
                }
                if (rCard == 3)
                {
                    Card.textCard = "-3 puncte";
                    Score.puncteP1 -= 3;
                }
                if (rCard == 4)
                {
                    Card.textCard = "7 puncte bonus";
                    Score.puncteP1 += 7;
                }
                if (rCard == 5)
                {
                    Card.textCard = "2 puncte bonus";
                    Score.puncteP1 += 2;
                }
                Control.MovePlayer(1);
                turn++;
            }
            else if (turn == 2)
            {
                if (rCard == 0)
                {
                    Card.textCard = "5 puncte bonus";
                    Score.puncteP2 += 5;
                }
                if (rCard == 1)
                {
                    Card.textCard = "1 punct bonus";
                    Score.puncteP2 += 1;
                }
                if (rCard == 2)
                {
                    Card.textCard = "-1 punct";
                    Score.puncteP2 -= 1;
                }
                if (rCard == 3)
                {
                    Card.textCard = "-3 puncte";
                    Score.puncteP2 -= 3;
                }
                if (rCard == 4)
                {
                    Card.textCard = "7 puncte bonus";
                    Score.puncteP2 += 7;
                }
                if (rCard == 5)
                {
                    Card.textCard = "2 puncte bonus";
                    Score.puncteP2 += 2;
                }
                Control.MovePlayer(2);
                turn ++;
            }
            else if (turn == 3)
            {
                if (rCard == 0)
                {
                    Card.textCard = "5 puncte bonus";
                    Score.puncteP3 += 5;
                }
                if (rCard == 1)
                {
                    Card.textCard = "1 punct bonus";
                    Score.puncteP3 += 1;
                }
                if (rCard == 2)
                {
                    Card.textCard = "-1 punct";
                    Score.puncteP3 -= 1;
                }
                if (rCard == 3)
                {
                    Card.textCard = "-3 puncte";
                    Score.puncteP3 -= 3;
                }
                if (rCard == 4)
                {
                    Card.textCard = "7 puncte bonus";
                    Score.puncteP3 += 7;
                }
                if (rCard == 5)
                {
                    Card.textCard = "2 puncte bonus";
                    Score.puncteP3 += 2;
                }
                Control.MovePlayer(3);
                turn = 1;
            }
        }
        if (ColorChange.enabledPlayers == 4)
        {
            if (turn == 1)
            {
                if (rCard == 0)
                {
                    Card.textCard = "5 puncte bonus";
                    Score.puncteP1 += 5;
                }
                if (rCard == 1)
                {
                    Card.textCard = "1 punct bonus";
                    Score.puncteP1 += 1;
                }
                if (rCard == 2)
                {
                    Card.textCard = "-1 punct";
                    Score.puncteP1 -= 1;
                }
                if (rCard == 3)
                {
                    Card.textCard = "-3 puncte";
                    Score.puncteP1 -= 3;
                }
                if (rCard == 4)
                {
                    Card.textCard = "7 puncte bonus";
                    Score.puncteP1 += 7;
                }
                if (rCard == 5)
                {
                    Card.textCard = "2 puncte bonus";
                    Score.puncteP1 += 2;
                }
                Control.MovePlayer(1);
                turn++;
            }
            else if (turn == 2)
            {
                if (rCard == 0)
                {
                    Card.textCard = "5 puncte bonus";
                    Score.puncteP2 += 5;
                }
                if (rCard == 1)
                {
                    Card.textCard = "1 punct bonus";
                    Score.puncteP2 += 1;
                }
                if (rCard == 2)
                {
                    Card.textCard = "-1 punct";
                    Score.puncteP2 -= 1;
                }
                if (rCard == 3)
                {
                    Card.textCard = "-3 puncte";
                    Score.puncteP2 -= 3;
                }
                if (rCard == 4)
                {
                    Card.textCard = "7 puncte bonus";
                    Score.puncteP2 += 7;
                }
                if (rCard == 5)
                {
                    Card.textCard = "2 puncte bonus";
                    Score.puncteP2 += 2;
                }
                Control.MovePlayer(2);
                turn++;
            }
            else if (turn == 3)
            {
                if (rCard == 0)
                {
                    Card.textCard = "5 puncte bonus";
                    Score.puncteP3 += 5;
                }
                if (rCard == 1)
                {
                    Card.textCard = "1 punct bonus";
                    Score.puncteP3 += 1;
                }
                if (rCard == 2)
                {
                    Card.textCard = "-1 punct";
                    Score.puncteP3 -= 1;
                }
                if (rCard == 3)
                {
                    Card.textCard = "-3 puncte";
                    Score.puncteP3 -= 3;
                }
                if (rCard == 4)
                {
                    Card.textCard = "7 puncte bonus";
                    Score.puncteP3 += 7;
                }
                if (rCard == 5)
                {
                    Card.textCard = "2 puncte bonus";
                    Score.puncteP3 += 2;
                }
                Control.MovePlayer(3);
                turn++;
            }
            else if (turn == 4)
            {
                if (rCard == 0)
                {
                    Card.textCard = "5 puncte bonus";
                    Score.puncteP4 += 5;
                }
                if (rCard == 1)
                {
                    Card.textCard = "1 punct bonus";
                    Score.puncteP4 += 1;
                }
                if (rCard == 2)
                {
                    Card.textCard = "-1 punct";
                    Score.puncteP4 -= 1;
                }
                if (rCard == 3)
                {
                    Card.textCard = "-3 puncte";
                    Score.puncteP4 -= 3;
                }
                if (rCard == 4)
                {
                    Card.textCard = "7 puncte bonus";
                    Score.puncteP4 += 7;
                }
                if (rCard == 5)
                {
                    Card.textCard = "2 puncte bonus";
                    Score.puncteP4 += 2;
                }
                Control.MovePlayer(4);
                turn = 1;
            }
        }
        ok = true;
    }
}
