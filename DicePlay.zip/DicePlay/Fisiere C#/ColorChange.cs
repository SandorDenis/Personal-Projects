﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ColorChange : MonoBehaviour
{

    public SpriteRenderer sP1, sP2, sP3, sP4;

    public static Image imgP1, imgP2, imgP3, imgP4, imgP1Menu, imgP2Menu, imgP3Menu, imgP4Menu, cartonas;

    public List<Sprite> color = new List<Sprite>();

    public Text nume1, nume2, nume3, nume4;

    private int currentOption = 0;

    public Button doiJucatoriP1Next, doiJucatoriP1Prev, doiJucatoriP2Next, doiJucatoriP2Prev,
        treiJucatoriP3Next, treiJucatoriP3Prev, patruJucatoriP4Next, patruJucatoriP4Prev, doiJucatoriP1NextForma,
        doiJucatoriP1PrevForma, doiJucatoriP2NextForma, doiJucatoriP2PrevForma, treiJucatoriP3PrevForma, treiJucatoriP3NextForma,
        patruJucatoriP4PrevForma, patruJucatoriP4NextForma;

    public InputField input1, input2, input3, input4;

    public GameObject panel;

    public Button playButton, exitButton;

    public static int enabledPlayers = 0;


    // Start is called before the first frame update
    void Start()
    {
        panel = GameObject.Find("Menu");

        cartonas = GameObject.Find("Cartonas").GetComponent<Image>();

        playButton = GameObject.Find("PlayButton").GetComponent<Button>();
        exitButton = GameObject.Find("ExitButton").GetComponent<Button>();

        sP1.enabled = false;
        sP2.enabled = false;
        sP3.enabled = false;
        sP4.enabled = false;

        doiJucatoriP1Next = GameObject.Find("Player1Next").GetComponent<Button>();
        doiJucatoriP1Prev = GameObject.Find("Player1Prev").GetComponent<Button>();
        doiJucatoriP2Next = GameObject.Find("Player2Next").GetComponent<Button>();
        doiJucatoriP2Prev = GameObject.Find("Player2Prev").GetComponent<Button>();
        treiJucatoriP3Next = GameObject.Find("Player3Next").GetComponent<Button>();
        treiJucatoriP3Prev = GameObject.Find("Player3Prev").GetComponent<Button>();
        patruJucatoriP4Next = GameObject.Find("Player4Next").GetComponent<Button>();
        patruJucatoriP4Prev = GameObject.Find("Player4Prev").GetComponent<Button>();

        doiJucatoriP1NextForma = GameObject.Find("FormaNextP1").GetComponent<Button>();
        doiJucatoriP1PrevForma = GameObject.Find("FormaPrevP1").GetComponent<Button>();
        doiJucatoriP2NextForma = GameObject.Find("FormaNextP2").GetComponent<Button>();
        doiJucatoriP2PrevForma = GameObject.Find("FormaPrevP2").GetComponent<Button>();
        treiJucatoriP3NextForma = GameObject.Find("FormaNextP3").GetComponent<Button>();
        treiJucatoriP3PrevForma = GameObject.Find("FormaPrevP3").GetComponent<Button>();
        patruJucatoriP4NextForma = GameObject.Find("FormaNextP4").GetComponent<Button>();
        patruJucatoriP4PrevForma = GameObject.Find("FormaPrevP4").GetComponent<Button>();

        imgP1 = GameObject.Find("Player1Image").GetComponent<Image>();
        imgP2 = GameObject.Find("Player2Image").GetComponent<Image>();
        imgP3 = GameObject.Find("Player3Image").GetComponent<Image>();
        imgP4 = GameObject.Find("Player4Image").GetComponent<Image>();

        imgP1Menu = GameObject.Find("Player1ImageMenu").GetComponent<Image>();
        imgP2Menu = GameObject.Find("Player2ImageMenu").GetComponent<Image>();
        imgP3Menu = GameObject.Find("Player3ImageMenu").GetComponent<Image>();
        imgP4Menu = GameObject.Find("Player4ImageMenu").GetComponent<Image>();

        input1 = GameObject.Find("InputFieldP1").GetComponent<InputField>();
        input2 = GameObject.Find("InputFieldP2").GetComponent<InputField>();
        input3 = GameObject.Find("InputFieldP3").GetComponent<InputField>();
        input4 = GameObject.Find("InputFieldP4").GetComponent<InputField>();

        imgP1.enabled = false;
        imgP2.enabled = false;
        imgP3.enabled = false;
        imgP4.enabled = false;

        imgP1Menu.enabled = false;
        imgP2Menu.enabled = false;
        imgP3Menu.enabled = false;
        imgP4Menu.enabled = false;

        cartonas.enabled = false;

        doiJucatoriP1Next.interactable = false;
        doiJucatoriP1Prev.interactable = false;
        doiJucatoriP2Next.interactable = false;
        doiJucatoriP2Prev.interactable = false;
        treiJucatoriP3Next.interactable = false;
        treiJucatoriP3Prev.interactable = false;
        patruJucatoriP4Next.interactable = false;
        patruJucatoriP4Prev.interactable = false;
        
        doiJucatoriP1NextForma.interactable = false;
        doiJucatoriP1PrevForma.interactable = false;
        doiJucatoriP2NextForma.interactable = false;
        doiJucatoriP2PrevForma.interactable = false;
        treiJucatoriP3NextForma.interactable = false;
        treiJucatoriP3PrevForma.interactable = false;
        patruJucatoriP4NextForma.interactable = false;
        patruJucatoriP4PrevForma.interactable = false;

        playButton.interactable = false;

        input1.interactable = false;
        input2.interactable = false;
        input3.interactable = false;
        input4.interactable = false;

        Score.scoreP1.gameObject.SetActive(false);
        Score.scoreP2.gameObject.SetActive(false);
        Score.scoreP3.gameObject.SetActive(false);
        Score.scoreP4.gameObject.SetActive(false);

    }

    // Update is called once per frame
    void Update()
    {

    }

    public void FormaPrevP1()
    {
        switch (currentOption)
        {
            case 0:
                currentOption = 4;
                break;
            case 1:
                currentOption = 4;
                break;
            case 2:
                currentOption = 4;
                break;
            case 3:
                currentOption = 4;
                break;
            case 4:
                currentOption = 0;
                break;
            case 5:
                currentOption = 0;
                break;
            case 6:
                currentOption = 0;
                break;
            case 7:
                currentOption = 0;
                break;
        }


        sP1.sprite = color[currentOption];
        imgP1.overrideSprite = sP1.sprite;
        imgP1Menu.overrideSprite = sP1.sprite;
    }

    public void FormaNextP1()
    {
        switch (currentOption)
        {
            case 0:
                currentOption = 4;
                break;
            case 1:
                currentOption = 4;
                break;
            case 2:
                currentOption = 4;
                break;
            case 3:
                currentOption = 4;
                break;
            case 4:
                currentOption = 0;
                break;
            case 5:
                currentOption = 0;
                break;
            case 6:
                currentOption = 0;
                break;
            case 7:
                currentOption = 0;
                break;
        }


        sP1.sprite = color[currentOption];
        imgP1.overrideSprite = sP1.sprite;
        imgP1Menu.overrideSprite = sP1.sprite;
    }

    public void FormaPrevP2()
    {
        switch (currentOption)
        {
            case 0:
                currentOption = 4;
                break;
            case 1:
                currentOption = 4;
                break;
            case 2:
                currentOption = 4;
                break;
            case 3:
                currentOption = 4;
                break;
            case 4:
                currentOption = 0;
                break;
            case 5:
                currentOption = 0;
                break;
            case 6:
                currentOption = 0;
                break;
            case 7:
                currentOption = 0;
                break;
        }


        sP2.sprite = color[currentOption];
        imgP2.overrideSprite = sP2.sprite;
        imgP2Menu.overrideSprite = sP2.sprite;
    }

    public void FormaNextP2()
    {
        switch (currentOption)
        {
            case 0:
                currentOption = 4;
                break;
            case 1:
                currentOption = 4;
                break;
            case 2:
                currentOption = 4;
                break;
            case 3:
                currentOption = 4;
                break;
            case 4:
                currentOption = 0;
                break;
            case 5:
                currentOption = 0;
                break;
            case 6:
                currentOption = 0;
                break;
            case 7:
                currentOption = 0;
                break;
        }


        sP2.sprite = color[currentOption];
        imgP2.overrideSprite = sP2.sprite;
        imgP2Menu.overrideSprite = sP2.sprite;
    }

    public void FormaPrevP3()
    {
        switch (currentOption)
        {
            case 0:
                currentOption = 4;
                break;
            case 1:
                currentOption = 4;
                break;
            case 2:
                currentOption = 4;
                break;
            case 3:
                currentOption = 4;
                break;
            case 4:
                currentOption = 0;
                break;
            case 5:
                currentOption = 0;
                break;
            case 6:
                currentOption = 0;
                break;
            case 7:
                currentOption = 0;
                break;
        }


        sP3.sprite = color[currentOption];
        imgP3.overrideSprite = sP3.sprite;
        imgP3Menu.overrideSprite = sP3.sprite;
    }

    public void FormaNextP3()
    {
        switch (currentOption)
        {
            case 0:
                currentOption = 4;
                break;
            case 1:
                currentOption = 4;
                break;
            case 2:
                currentOption = 4;
                break;
            case 3:
                currentOption = 4;
                break;
            case 4:
                currentOption = 0;
                break;
            case 5:
                currentOption = 0;
                break;
            case 6:
                currentOption = 0;
                break;
            case 7:
                currentOption = 0;
                break;
        }


        sP3.sprite = color[currentOption];
        imgP3.overrideSprite = sP3.sprite;
        imgP3Menu.overrideSprite = sP3.sprite;
    }

    public void FormaPrevP4()
    {
        switch (currentOption)
        {
            case 0:
                currentOption = 4;
                break;
            case 1:
                currentOption = 4;
                break;
            case 2:
                currentOption = 4;
                break;
            case 3:
                currentOption = 4;
                break;
            case 4:
                currentOption = 0;
                break;
            case 5:
                currentOption = 0;
                break;
            case 6:
                currentOption = 0;
                break;
            case 7:
                currentOption = 0;
                break;
        }


        sP4.sprite = color[currentOption];
        imgP4.overrideSprite = sP4.sprite;
        imgP4Menu.overrideSprite = sP4.sprite;
    }

    public void FormaNextP4()
    {
        switch (currentOption)
        {
            case 0:
                currentOption = 4;
                break;
            case 1:
                currentOption = 4;
                break;
            case 2:
                currentOption = 4;
                break;
            case 3:
                currentOption = 4;
                break;
            case 4:
                currentOption = 0;
                break;
            case 5:
                currentOption = 0;
                break;
            case 6:
                currentOption = 0;
                break;
            case 7:
                currentOption = 0;
                break;
        }


        sP4.sprite = color[currentOption];
        imgP4.overrideSprite = sP4.sprite;
        imgP4Menu.overrideSprite = sP4.sprite;
    }

    public void NextOptionP1()
    {
        currentOption++;
        if (currentOption == 4)
            currentOption = 0;

        if (currentOption == color.Count)
            currentOption = 4;

        sP1.sprite = color[currentOption];
        imgP1.overrideSprite = sP1.sprite;
        imgP1Menu.overrideSprite = sP1.sprite;

    }

    public void PreviousOptionP1()
    {
        currentOption--;

        if (currentOption == 3)
            currentOption = color.Count - 1;

        if (currentOption < 0)
            currentOption = 3;

        sP1.sprite = color[currentOption];

        imgP1.overrideSprite = sP1.sprite;
        imgP1Menu.overrideSprite = sP1.sprite;
    }

    public void NextOptionP2()
    {
        currentOption++;
        if (currentOption == 4)
            currentOption = 0;

        if (currentOption == color.Count)
            currentOption = 4;

        sP2.sprite = color[currentOption];
        imgP2.overrideSprite = sP2.sprite;
        imgP2Menu.overrideSprite = sP2.sprite;
    }

    public void PreviousOptionP2()
    {
        currentOption--;

        if (currentOption == 3)
            currentOption = color.Count - 1;

        if (currentOption < 0)
            currentOption = 3;
        sP2.sprite = color[currentOption];
        imgP2.overrideSprite = sP2.sprite;
        imgP2Menu.overrideSprite = sP2.sprite;
    }

    public void NextOptionP3()
    {
        currentOption++;
        if (currentOption == 4)
            currentOption = 0;

        if (currentOption == color.Count)
            currentOption = 4;

        sP3.sprite = color[currentOption];
        imgP3.overrideSprite = sP3.sprite;
        imgP3Menu.overrideSprite = sP3.sprite;
    }

    public void PreviousOptionP3()
    {
        currentOption--;

        if (currentOption == 3)
            currentOption = color.Count - 1;

        if (currentOption < 0)
            currentOption = 3;
        sP3.sprite = color[currentOption];
        imgP3.overrideSprite = sP3.sprite;
        imgP3Menu.overrideSprite = sP3.sprite;
    }

    public void NextOptionP4()
    {
        currentOption++;
        if (currentOption == 4)
            currentOption = 0;

        if (currentOption == color.Count)
            currentOption = 4;

        sP4.sprite = color[currentOption];
        imgP4.overrideSprite = sP4.sprite;
        imgP4Menu.overrideSprite = sP4.sprite;
    }

    public void PreviousOptionP4()
    {
        currentOption--;

        if (currentOption == 3)
            currentOption = color.Count - 1;

        if (currentOption < 0)
            currentOption = 3;
        sP4.sprite = color[currentOption];
        imgP4.overrideSprite = sP4.sprite;
        imgP4Menu.overrideSprite = sP4.sprite;
    }

    public void TwoPlayers()
    {
        sP1.enabled = true;
        sP2.enabled = true;
        sP3.enabled = false;
        sP4.enabled = false;

        doiJucatoriP1Next.interactable = true;
        doiJucatoriP1Prev.interactable = true;
        doiJucatoriP2Next.interactable = true;
        doiJucatoriP2Prev.interactable = true;
        treiJucatoriP3Next.interactable = false;
        treiJucatoriP3Prev.interactable = false;
        patruJucatoriP4Next.interactable = false;
        patruJucatoriP4Prev.interactable = false;

        doiJucatoriP1NextForma.interactable = true;
        doiJucatoriP1PrevForma.interactable = true;
        doiJucatoriP2NextForma.interactable = true;
        doiJucatoriP2PrevForma.interactable = true;
        treiJucatoriP3NextForma.interactable = false;
        treiJucatoriP3PrevForma.interactable = false;
        patruJucatoriP4NextForma.interactable = false;
        patruJucatoriP4PrevForma.interactable = false;

        enabledPlayers = 2;

        imgP1.enabled = true;
        imgP2.enabled = true;
        imgP3.enabled = false;
        imgP4.enabled = false;

        imgP1Menu.enabled = true;
        imgP2Menu.enabled = true;
        imgP3Menu.enabled = false;
        imgP4Menu.enabled = false;

        Ranking.winP1.enabled = true;
        Ranking.winP2.enabled = true;
        Ranking.winP3.enabled = false;
        Ranking.winP4.enabled = false;

        input1.interactable = true;
        input2.interactable = true;
        input3.interactable = false;
        input4.interactable = false;

        playButton.interactable = true;

    }

    public void ThreePlayers()
    {
        sP1.enabled = true;
        sP2.enabled = true;
        sP3.enabled = true;
        sP4.enabled = false;

        doiJucatoriP1Next.interactable = true;
        doiJucatoriP1Prev.interactable = true;
        doiJucatoriP2Next.interactable = true;
        doiJucatoriP2Prev.interactable = true;
        treiJucatoriP3Next.interactable = true;
        treiJucatoriP3Prev.interactable = true;
        patruJucatoriP4Next.interactable = false;
        patruJucatoriP4Prev.interactable = false;

        doiJucatoriP1NextForma.interactable = true;
        doiJucatoriP1PrevForma.interactable = true;
        doiJucatoriP2NextForma.interactable = true;
        doiJucatoriP2PrevForma.interactable = true;
        treiJucatoriP3NextForma.interactable = true;
        treiJucatoriP3PrevForma.interactable = true;
        patruJucatoriP4NextForma.interactable = false;
        patruJucatoriP4PrevForma.interactable = false;

        enabledPlayers = 3;

        imgP1.enabled = true;
        imgP2.enabled = true;
        imgP3.enabled = true;
        imgP4.enabled = false;

        imgP1Menu.enabled = true;
        imgP2Menu.enabled = true;
        imgP3Menu.enabled = true;
        imgP4Menu.enabled = false;

        Ranking.winP1.enabled = true;
        Ranking.winP2.enabled = true;
        Ranking.winP3.enabled = true;
        Ranking.winP4.enabled = false;

        input1.interactable = true;
        input2.interactable = true;
        input3.interactable = true;
        input4.interactable = false;

        playButton.interactable = true;

    }

    public void FourPlayers()
    {
        sP1.enabled = true;
        sP2.enabled = true;
        sP3.enabled = true;
        sP4.enabled = true;


        doiJucatoriP1Next.interactable = true;
        doiJucatoriP1Prev.interactable = true;
        doiJucatoriP2Next.interactable = true;
        doiJucatoriP2Prev.interactable = true;
        treiJucatoriP3Next.interactable = true;
        treiJucatoriP3Prev.interactable = true;
        patruJucatoriP4Next.interactable = true;
        patruJucatoriP4Prev.interactable = true;

        doiJucatoriP1NextForma.interactable = true;
        doiJucatoriP1PrevForma.interactable = true;
        doiJucatoriP2NextForma.interactable = true;
        doiJucatoriP2PrevForma.interactable = true;
        treiJucatoriP3NextForma.interactable = true;
        treiJucatoriP3PrevForma.interactable = true;
        patruJucatoriP4NextForma.interactable = true;
        patruJucatoriP4PrevForma.interactable = true;

        enabledPlayers = 4;

        imgP1.enabled = true;
        imgP2.enabled = true;
        imgP3.enabled = true;
        imgP4.enabled = true;

        imgP1Menu.enabled = true;
        imgP2Menu.enabled = true;
        imgP3Menu.enabled = true;
        imgP4Menu.enabled = true;

        Ranking.winP1.enabled = true;
        Ranking.winP2.enabled = true;
        Ranking.winP3.enabled = true;
        Ranking.winP4.enabled = true;

        input1.interactable = true;
        input2.interactable = true;
        input3.interactable = true;
        input4.interactable = true;

        playButton.interactable = true;
    }

    public void playButtonClick()
    {
        panel.gameObject.SetActive(false);
        cartonas.enabled = true;

        if (sP1.enabled && sP2.enabled)
        {
            Score.scoreP1.gameObject.SetActive(true);
            Score.scoreP2.gameObject.SetActive(true);
        }

        if (sP1.enabled && sP2.enabled && sP3.enabled)
        {
            Score.scoreP1.gameObject.SetActive(true);
            Score.scoreP2.gameObject.SetActive(true);
            Score.scoreP3.gameObject.SetActive(true);
        }

        if (sP1.enabled && sP2.enabled && sP3.enabled && sP4.enabled)
        {
            Score.scoreP1.gameObject.SetActive(true);
            Score.scoreP2.gameObject.SetActive(true);
            Score.scoreP3.gameObject.SetActive(true);
            Score.scoreP4.gameObject.SetActive(true);
        }
    }

    public void exitButtonClick()
    {
        Application.Quit();
    }

}
