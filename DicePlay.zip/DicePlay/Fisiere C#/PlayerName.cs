﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerName : MonoBehaviour
{
    public static Text numeP1, numeP2, numeP3, numeP4;
    public static InputField inputP1, inputP2, inputP3, inputP4;
    public static string numeJucator1 = "";
    public static string numeJucator2 = "";
    public static string numeJucator3 = "";
    public static string numeJucator4 = "";

    // Start is called before the first frame update
    void Start()
    {
        numeP1 = transform.Find("Player1Name").GetComponent<Text>();
        inputP1 = GameObject.Find("InputFieldP1").GetComponent<InputField>();
        numeJucator1 = inputP1.text;

        numeP2 = transform.Find("Player2Name").GetComponent<Text>();
        inputP2 = GameObject.Find("InputFieldP2").GetComponent<InputField>();
        numeJucator2 = inputP2.text;

        numeP3 = transform.Find("Player3Name").GetComponent<Text>();
        inputP3 = GameObject.Find("InputFieldP3").GetComponent<InputField>();
        numeJucator3 = inputP3.text;

        numeP4 = transform.Find("Player4Name").GetComponent<Text>();
        inputP4 = GameObject.Find("InputFieldP4").GetComponent<InputField>();
        numeJucator4 = inputP4.text;

    }

    // Update is called once per frame
    void Update()
    {
        numeJucator1 = inputP1.text;
        if (numeJucator1 == "")
            numeJucator1 = "Jucator 1";
        numeP1.text = numeJucator1;

        numeJucator2 = inputP2.text;
        if (numeJucator2 == "")
            numeJucator2 = "Jucator 2";
        numeP2.text = numeJucator2;

        numeJucator3 = inputP3.text;
        if (numeJucator3 == "")
            numeJucator3 = "Jucator 3";
        numeP3.text = numeJucator3;

        numeJucator4 = inputP4.text;
        if (numeJucator4 == "")
            numeJucator4 = "Jucator 4";
        numeP4.text = numeJucator4;

        if (ColorChange.enabledPlayers == 2)
        {
            numeP3.text = "";
            numeP4.text = "";

        }
        if (ColorChange.enabledPlayers == 3)
        {
            numeP4.text = "";
        }

    }
}
