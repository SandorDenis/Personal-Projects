﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Path : MonoBehaviour
{

    public Transform[] waypoints;
    [SerializeField]
    private float movementSpeed = 1f;
    [HideInInspector]
    public int waypointIndex = 0;
    public bool movement = false;

    // Start is called before the first frame update
    void Start()
    {
        transform.position = waypoints[waypointIndex].transform.position;

    }

    // Update is called once per frame
    void Update()
    {

        if (movement)
            Move();
    }

    private void Move()
    {
        if (waypointIndex <= waypoints.Length - 1) 
            transform.position = Vector2.MoveTowards(transform.position, waypoints[waypointIndex].transform.position, movementSpeed * Time.deltaTime);

        if (waypointIndex < waypoints.Length)
            if (transform.position == waypoints[waypointIndex].transform.position)
            {
                waypointIndex += 1;
            }

    }

}
