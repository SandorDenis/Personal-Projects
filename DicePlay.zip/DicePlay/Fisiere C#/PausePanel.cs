﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PausePanel : MonoBehaviour
{

    public static GameObject panelPause;

    // Start is called before the first frame update
    void Start()
    {
        panelPause = GameObject.Find("PanelPause");
        panelPause.gameObject.SetActive(false);
    }

}
