﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class TwoPlayersButton : MonoBehaviour
{
    public static Image imgP1, imgP2, imgP3, imgP4;

    public SpriteRenderer sP1, sP2, sP3, sP4;
    public Sprite[] color;
    public Sprite[] options;
    private int currentOption = 0;
    public Button PB2;

    // Start is called before the first frame update
    void Start()
    {
        sP1 = GetComponent<SpriteRenderer>();
        color = Resources.LoadAll<Sprite>("Planets/");
        sP1.sprite = color[0];

        imgP1 = GameObject.Find("Player1Image").GetComponent<Image>();
        imgP2 = GameObject.Find("Player2Image").GetComponent<Image>();
        imgP3 = GameObject.Find("Player3Image").GetComponent<Image>();
        imgP4 = GameObject.Find("Player4Image").GetComponent<Image>();

        imgP1.enabled = false;
        imgP2.enabled = false;
        imgP3.enabled = false;
        imgP4.enabled = false;

        PB2 = GameObject.Find("2Players").GetComponent<Button>();
    }


    // Update is called once per frame
    void Update()
    {
        PB2.onClick.AddListener(visibleTwoPlayers);
    }

    public void visibleTwoPlayers()
    {
        imgP1.enabled = true;
        imgP2.enabled = true;
        imgP3.enabled = false;
        imgP4.enabled = false;
    }

    public void visibleThreePlayers()
    {
        imgP1.enabled = true;
        imgP2.enabled = true;
        imgP3.enabled = true;
        imgP4.enabled = false;
    }

    public void visibleFourPlayers()
    {
        imgP1.enabled = true;
        imgP2.enabled = true;
        imgP3.enabled = true;
        imgP4.enabled = true;
    }

    public void NextOption()
    {
        currentOption++;
        if (currentOption > options.Length)
            currentOption = 0;

        sP1.sprite = options[currentOption];
    }

    public void PreviousOption()
    {
        currentOption--;
        if (currentOption <= 0)
            currentOption = options.Length - 1;
        sP1.sprite = options[currentOption];
    }
}
